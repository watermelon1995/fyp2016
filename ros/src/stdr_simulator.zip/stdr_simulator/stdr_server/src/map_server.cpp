/******************************************************************************
   STDR Simulator - Simple Two DImensional Robot Simulator
   Copyright (C) 2013 STDR Simulator
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA

   Authors :
   * Manos Tsardoulias, etsardou@gmail.com
   * Aris Thallas, aris.thallas@gmail.com
   * Chris Zalidis, zalidis@gmail.com
******************************************************************************/

#include <stdr_server/map_server.h>

namespace stdr_server {

  /**
  @brief Constructor by filename
  @param fname [const std::string&] The file name
  @return void
  **/
  MapServer::MapServer(const std::string& fname)
  {

    map_ = map_loader::loadMap(fname);

    meta_data_message_ = map_.info;
    createBox();
    publishData();
  }

  /**
  @brief Constructor by occupancy grid map
  @param map [const nav_msgs::OccupancyGrid&] The occupancy grid map
  @return void
  **/
  MapServer::MapServer(const nav_msgs::OccupancyGrid& map)
  {

    map_ = map;

    meta_data_message_ = map_.info;
    createBox();
    publishData();
  }

  static float RandomNumber(float Min, float Max)
  {
      return ((float(rand()) / float(RAND_MAX)) * (Max - Min)) + Min;
  }

  void MapServer::createBox(){
    srand (time(NULL));
    box_props.resize(30);
    for (int i = 0; i<30;i++){
      // box_props[i].angle = RandomNumber(0.0, 2*3.14);
      box_props[i].speed_x = RandomNumber(-5.0, 5.0);
      box_props[i].speed_y = RandomNumber(-5.0, 5.0);
      box_props[i].x1 = rand() % (775-100)+50;
      box_props[i].x2 = box_props[i].x1 + 20;
      box_props[i].y1 = rand() % (746-100)+50;
      box_props[i].y2 = box_props[i].y1 + 20;
    }
  }

  void MapServer::updateBox(){
    float temp_x;
    float temp_y;
    float new_x;
    float new_y;
    srand (time(NULL));
    int new_position_ok = 0;
    for (int i = 0; i< 30 ;i++){
      //Clear Old Position

      for (int j = box_props[i].y1 ; j < box_props[i].y1 + 20 ;j++){
        for (int w = box_props[i].x1 ; w < box_props[i].x1 + 20 ; w++){
          map_.data[j * map_.info.width + w] = 0;
        }
      }
    }

    for ( int  i =0 ; i< 30 ;i++){
      temp_x = box_props[i].x1;
      temp_y = box_props[i].y1;
      //Write New Position
      new_position_ok = 0;
      new_x = floor( box_props[i].x1 +  box_props[i].speed_x );
      new_y = floor( box_props[i].y1 +  box_props[i].speed_y );

      if ( new_x < 50 || new_x + 20 > 775-50){
        if (box_props[i].speed_x > 0){
          box_props[i].speed_x = RandomNumber(-5.0, 0.0);
        }else{
          box_props[i].speed_x = RandomNumber(0.0, 5.0);
        }
        new_x = floor( box_props[i].x1 +  2*box_props[i].speed_x );
      }

      if ( new_y < 50 || new_y + 20 > 746-50){
        if (box_props[i].speed_y > 0){
          box_props[i].speed_y = RandomNumber(-5.0, 0.0);
        }else{
          box_props[i].speed_y = RandomNumber(0.0, 5.0);
        }
        new_y = floor( box_props[i].y1 + 2* box_props[i].speed_y );
      }
      // while(new_position_ok != 1){
      //
      //
      //   if ( new_x < 50 || new_x + 20 > 775-50){
      //     box_props[i].speed_x = -box_props[i].speed_x;
      //   }else if (new_y < 50 || new_y + 20 > 746 -50){
      //     box_props[i].speed_y = -box_props[i].speed_y;
      //   }else{
      //     new_position_ok = 1;
      //   }
      // }


      temp_x = new_x;
      temp_y = new_y;
      box_props[i].x1 = new_x;
      box_props[i].x2 = new_x+20;
      box_props[i].y1 = new_y;
      box_props[i].y2 = new_y+20;




      for (int j = temp_y ; j< temp_y + 20 ;j++){
        for (int w = temp_x ; w < temp_x +20 ;w++){
            map_.data[j * map_.info.width + w] = 100;
        }
      }

    }
  }

  void MapServer::resetBox(){
    for (int i = 0; i< 30 ;i++){
      //Clear Old Position
      for (int j = box_props[i].y1 ; j < box_props[i].y1 + 20 ;j++){
        for (int w = box_props[i].x1 ; w < box_props[i].x1 + 20 ; w++){
          map_.data[j * map_.info.width + w] = 0;
        }
      }
    }
    for (int i = 0;i<30;i++){
      box_props[i].speed_x = RandomNumber(-5.0, 5.0);
      box_props[i].speed_y = RandomNumber(-5.0, 5.0);
      box_props[i].x1 = rand() % (775-100)+50;
      box_props[i].x2 = box_props[i].x1 + 20;
      box_props[i].y1 = rand() % (746-100)+50;
      box_props[i].y2 = box_props[i].y1 + 20;
    }
    updateBox();
  }

  void MapServer::publishDataOnce(void){
    metadata_pub.publish( meta_data_message_ );
    map_pub.publish( map_ );
  }
  /**
  @brief Publishes the map data and metadata
  @return void
  **/
  void MapServer::publishData(void)
  {

    tfTimer = n.createTimer(ros::Duration(0.1),
      &MapServer::publishTransform, this);


    // updateBox();

    // for ( int i = 0 ; i < 30 ;i++){
    //   for ( int j = 0 ; j< 30 ;j++){
    //     map_.data[i * map_.info.width + j] = 100;
    //   }
    // }
    //
    // for ( int i = 746-30 ; i < 746 ;i++){
    //   for ( int j = 0 ; j< 30 ;j++){
    //     map_.data[i * map_.info.width + j] = 100;
    //   }
    // }
    //
    // for ( int i = 746-30 ; i < 746 ;i++){
    //   for ( int j = 775-30 ; j< 775 ;j++){
    //     map_.data[i * map_.info.width + j] = 100;
    //   }
    // }
    //
    // for ( int i = 0 ; i < 30 ;i++){
    //   for ( int j = 775-30 ; j< 775;j++){
    //     map_.data[i * map_.info.width + j] = 100;
    //   }
    // }

    //!< Latched publisher for metadata
    metadata_pub= n.advertise<nav_msgs::MapMetaData>("map_metadata", 1, true);
    metadata_pub.publish( meta_data_message_ );

    //!< Latched publisher for data
    map_pub = n.advertise<nav_msgs::OccupancyGrid>("map", 1, true);
    map_pub.publish( map_ );
  }

  /**
  @brief Publishes the map to map_static transform
  @param ev [const ros::TimerEvent&] A ROS timer event
  @return void
  **/
  void MapServer::publishTransform(const ros::TimerEvent&) {

    tf::Vector3 translation(
      map_.info.origin.position.x,
      map_.info.origin.position.y,
      0);

    tf::Quaternion rotation;

    rotation.setRPY(0, 0, tf::getYaw(map_.info.origin.orientation));

    tf::Transform worldTomap(rotation, translation);

    tfBroadcaster.sendTransform(
      tf::StampedTransform(worldTomap, ros::Time::now(), "map", "map_static"));

  }

} // end of namespace stdr_server
